def add_one(number):
    return number + 1


def square_number(number):
    return number ** 2
