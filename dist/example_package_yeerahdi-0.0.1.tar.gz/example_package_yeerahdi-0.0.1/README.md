# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

![Tests](https://github.com/mattdmv/python-package-with-github-actions/actions/workflows/test-python-package.yml/badge.svg)
