import pytest

from example_package_yeerahdi.example import add_one


def test_add_one():
    assert add_one(4) == 5
