def square_number(number):
    return number ** 2
